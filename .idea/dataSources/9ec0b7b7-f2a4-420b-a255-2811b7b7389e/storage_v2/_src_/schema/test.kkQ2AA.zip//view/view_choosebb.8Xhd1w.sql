create definer = root@localhost view view_choosebb as
select `test`.`choosebb`.`Bb1` AS `View_bb1`,
       `test`.`choosebb`.`Bb4` AS `View_bb2`,
       `test`.`choosebb`.`Bb5` AS `View_bb3`
from `test`.`choosebb`;

